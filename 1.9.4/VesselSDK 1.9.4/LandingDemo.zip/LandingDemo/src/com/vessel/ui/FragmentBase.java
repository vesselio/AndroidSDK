package com.vessel.ui;

import android.app.Activity;
import android.support.v4.app.Fragment;

/**
 * Base class for fragments.
 * @author dev
 *
 */
public class FragmentBase extends Fragment {

	public FragmentBase() {

	}

	@Override
	public void onAttach(final Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
	}

}
