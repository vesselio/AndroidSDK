adb shell pm clear com.vessel.landingdemo && adb shell am start -a android.intent.action.MAIN -n com.vessel.landingdemo/.SplashActivity
